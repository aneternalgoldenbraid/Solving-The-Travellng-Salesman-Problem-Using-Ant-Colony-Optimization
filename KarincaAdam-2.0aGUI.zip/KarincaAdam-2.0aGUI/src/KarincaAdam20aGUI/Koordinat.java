/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KarincaAdam20aGUI;

/**
 *
 * @author mustafa.helvaci
 */
public class Koordinat {
    double x;
    double y;

    public Koordinat(double x, double y) {
        super();
        this.x = x;
        this.y = y;
    }
    
}
